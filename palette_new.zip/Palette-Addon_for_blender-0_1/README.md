# Palette
Blender addon
Work in progress

Color Palette management tool, unified across the blender interface : 3D view, cycles nodes, internal nodes, world nodes, compositing nodes

Palette are .gpl format, usable with gimp krita

Possible importer for Adobe suite 

Possible importer for Adobe Palette and xml format

Pantone creation through several techniques (complementary colors, triad, shade, similarity...) around a "master" color
